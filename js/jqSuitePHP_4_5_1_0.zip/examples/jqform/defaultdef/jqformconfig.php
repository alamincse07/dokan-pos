<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
$SERVER_HOST = "";        // the host name
$SELF_PATH = "";    // the web path to the project without http
$CODE_PATH = "../../../php/"; // the physical path to the php files

include '../../../jq-config.php'
?>
