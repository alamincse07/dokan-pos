<?php
// ** MySQL settings ** //
//define('DB_NAME', 'northwind');    // The name of the database
//define('DB_HOST', 'localhost');    // 99% chance you won't need to change this value
define('DB_DSN','mysql:host=localhost;dbname=northwind');
define('DB_USER', '');     // Your MySQL username
define('DB_PASSWORD', ''); // ...and password

define('ABSPATH', dirname(__FILE__).'/');
//require_once(ABSPATH.'tabs.php');
?>